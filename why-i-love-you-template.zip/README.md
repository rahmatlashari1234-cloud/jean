# Why I Love You — Romantic Website Template 💕

A romantic **"Why I Love You"** website template, complete with background audio, animations, handwritten typography, and interactive chapters.

---

## 📁 Project Structure

```text
why-i-love-you-clone/
├── index.html                   # Main entry point with Google Fonts & scripts
├── server.js                    # Zero-dependency local server with SPA fallback
├── customize.js                 # 1-command name personalizer
├── package.json                 # Project configuration
├── audio/
│   └── background-music.mp3     # Full romantic background soundtrack
└── assets/
    ├── index-BheLexMn.css       # Full Tailwind styles & romantic pastel themes
    ├── index-CGsF1MLl.js        # Full React application & interactive routing
    ├── landing-cat-CO5wZa_9.png # Hero greeting doodle cat
    ├── story-cat-CjG9yX8l.png   # Story chapter doodle cat
    ├── reasons-cat-D7qfKecV.png # Reasons section doodle cat
    ├── littlethings-cat-CaRCl2Uu.png # Little things section doodle cat
    ├── gifts-cat-C-j6tJ2G.png   # Gifts & surprises doodle cat
    ├── comfort-sad-cat-CkSEnu3R.png # Comfort (sad) doodle cat
    └── comfort-hug-cat-9Fv-nEVe.png # Comfort (hug) doodle cat
```

---

## 🚀 How to Run Locally

### Option 1: Start with Node.js
From this directory, run:
```bash
node server.js
```
Then open: [http://localhost:3000](http://localhost:3000)

### Option 2: Using npm
```bash
npm start
```

---

## ✏️ How to Personalize

### 1. Change Partner Name
By default, the demo was addressed to "Kinza". To instantly replace it with your partner's name:
```bash
node customize.js "YourPartnerName"
```
*Example:* `node customize.js "Ayesha"` or `node customize.js "Sophia"`

### 2. Change the Background Song
Replace the file located at:
```text
audio/background-music.mp3
```
with any MP3 file of your choice (keep the filename as `background-music.mp3`).

### 3. Change Images
Replace any of the doodle cat illustrations in `assets/` with your own relationship photos or keep the cute doodle art.

---

## 🌐 Free 1-Click Deployment (Netlify / Vercel / GitHub Pages)

1. **Netlify:** Drag-and-drop this entire folder into [Netlify Drop](https://app.netlify.com/drop).
2. **Vercel:** Run `npx vercel` inside this folder.
3. **GitHub Pages:** Push this repository to GitHub and enable GitHub Pages in repo settings.
