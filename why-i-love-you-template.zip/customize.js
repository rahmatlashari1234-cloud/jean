/**
 * Easy Customizer Script for "Why I Love You" Template Clone
 * Usage:
 *   node customize.js "PartnerName"
 * Example:
 *   node customize.js "Emma"
 */

const fs = require('fs');
const path = require('path');

const newName = process.argv[2];

if (!newName || !newName.trim()) {
  console.log('❌ Please provide a name. Example: node customize.js "Sarah"');
  process.exit(1);
}

const bundlePath = path.join(__dirname, 'assets', 'index-CGsF1MLl.js');

if (!fs.existsSync(bundlePath)) {
  console.error('❌ Bundle file not found at:', bundlePath);
  process.exit(1);
}

let content = fs.readFileSync(bundlePath, 'utf8');

// Replace partner name
// The original name used in the demo is "Kinza"
const occurrences = (content.match(/Kinza/g) || []).length;

if (occurrences === 0) {
  console.log('⚠️ Warning: "Kinza" was not found in the bundle (maybe it was already replaced).');
} else {
  content = content.replace(/Kinza/g, newName.trim());
  fs.writeFileSync(bundlePath, content, 'utf8');
  console.log(`✅ Successfully customized! Replaced ${occurrences} occurrences of name with: "${newName.trim()}"`);
}
